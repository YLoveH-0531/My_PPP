@echo off
config -set "cpu cycles=8000"
MARIO.EXE
