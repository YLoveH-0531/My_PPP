
                                MARIO & LUIGI

                    http://home.wxs.nl/~mike.wiering/mario/
                       Mike Wiering (mike.wiering@wxs.nl)


Introduction

   This is a small Mario game I made in 1994. I wrote this game to practice
   VGA programming. My goal was to create a PC game with parallax scrolling
   layers that would run smoothly on my 25 MHz 486 computer. The game has
   six levels and the size of the .EXE file is below 64K!

   This game was programmed in Turbo Pascal. The source code is now available
   at http://www.wieringsoftware.nl/mario/.


Controls

   All menus can be controlled with the arrow keys and Enter to select. Press
   Esc to go back or exit.

   During the game:

      Left, Right        -  Walk
      Ctrl Left, Right   -  Run
      Alt                -  Jump
      Space              -  Fire (aim with Up and Down)
      Down               -  Enter pipe (only some)
      Esc                -  Quit

   You can also use a joystick. To calibrate, run:

      mario -j


Distribution

   This game is freeware. You may copy it, as long as you make NO changes to
   the game or any associated files. DO NOT add your own documentation,
   registration forms, loaders, "Done by ..." messages, etc. Just leave the
   original ZIP file as it is.


More games

   If you like this kind of games, check out the following site for more:

      http://www.wieringsoftware.nl
 

Disclaimer

   This software is provided "AS IS" without warranty of any kind, either
   expressed or implied, including, but not limited to, the implied
   warranties of merchantability and fitness for a particular purpose. The
   entire risk as to the quality and performance of this software is with
   you.

   In no event will the author, distributor or any other party be liable to
   you for damages, including any general, special, incidental or
   consequential damages arising out of the use, misuse or inability to use
   this software (including but not limited to loss of data or losses
   sustained by you or third parties or a failure of this software to operate
   with any other software), even if such party has been advised of the
   possibility of such damages.
